#ifndef __GAMECONTROLLER_H 
#define __GAMECONTROLLER_H

#ifndef _GLCD_H
#define _GLCD_H
#define HEIGTH 31
#define LENGTH 28
#define scale 8
#define spacing_x 10
#define spacing_y 60

#include <GLCD/GLCD.h>

#endif

struct Position {
	int x;
	int y;
};

int active; //if the player is moving or nor  1 yes 0 no
int status_game; // 1:start 0:pause 3:end





extern uint8_t board[HEIGTH][LENGTH];

extern int pac_pos_x;
extern int pac_pos_y;
extern int current_board_x;
extern int current_board_y;

typedef struct {
    int x;
    int y;
} Punto;

// Dichiarazione dell'array come extern
extern Punto punti_array[10];
extern int special;

void gameEnd();
void StartGame();
void gamePause();
void gameResume();
void gameVictory();

int score; 
void setScore();

void eatPills(int x, int y, int type_points);
void DrawPacMan(int x, int y, int size);
void LCD_DrawBoard();
int MovePacMan(int direction); // 1: up 0:down 2;right 3:left 
#endif 
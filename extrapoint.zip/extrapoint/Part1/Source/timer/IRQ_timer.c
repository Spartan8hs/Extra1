/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include <string.h>
#include "LPC17xx.h"
#include "timer.h"
#include "../GLCD/GLCD.h" 
#include "../TouchPanel/TouchPanel.h"
#include <stdio.h> /*for sprintf*/

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
int timer_game = 0;
int ch = 0;

void TIMER0_IRQHandler (void)
{
	int newValue = timer_game - 1 ;
	setTimer(newValue);
	if(newValue <= 0) gameEnd();
	
  LPC_TIM0->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER1_IRQHandler (void)
{
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/

void initTimer(int value, int change){
	timer_game = value;
	ch = change;
	setTimer(value);
}

void setTimer(int newValue) { 
	
   
		LCD_delete_GUI(30, 20, 120 , 20);
		
		timer_game = newValue;
		char tempo[50];  // Creazione di una variabile stringa con spazio sufficiente
	
		sprintf(tempo, "%d", timer_game); 
		GUI_Text(30, 20, (uint8_t *)tempo, White, Black);
		
		GUI_Text(60, 20, (uint8_t *)"sec", White, Black);
		
	
}
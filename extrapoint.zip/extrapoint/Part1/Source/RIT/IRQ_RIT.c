/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "../led/led.h"

int actual_direction = -1;
/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

volatile int down=0;

void RIT_IRQHandler (void)
{					
	static int up=0;
	static int down_press=0;
	static int right=0;
	static int left=0;
	int res = 0;
	int direction; 
	
	direction = joystick_direction();
	if (actual_direction!=direction && direction!= -1) actual_direction = direction;
		
	switch (actual_direction){
			case 0:{
				res = MovePacMan(0);
				setScore();
				if(res == -1){
						res=0;
						actual_direction=-1;
						direction=-1;
				}
				break;				
			}
			case 1:{
			res = MovePacMan(1);
				setScore();
			if(res == -1){
					res=0;
					actual_direction=-1;
					direction=-1;
				}	
			break;
			}
			case 2:{
			res = MovePacMan(2);
				setScore();
			if(res == -1){
					res=0;
					actual_direction=-1;
					direction=-1;
				}
			break;
			}
			case 3:{
			res = MovePacMan(3);
				setScore();
		  if(res == -1){
					res=0;
					actual_direction=-1;
					direction=-1;
				}
			break;
			}
			case -1:{break;}
			
			default:{}
		
		}
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/

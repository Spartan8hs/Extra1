#include "GameController.h"
#include <stdio.h>



int prev_score = 0;

int special = 0;
int eaten = 0;


volatile int count_score = 0;
volatile int count_score_special = 0;


struct Position PacMan; //draw 
struct Position currentP; //position on board 
struct Position LastDrawLife; // last position of life drawn 

int score =0;


int extra_life = 0;
			
uint8_t board[HEIGTH][LENGTH] = {
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, 
        {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 0, 0, 1, 1, 0, 0, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {4, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 6},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1}, 
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 1, 1, 1, 1, 1, 2, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 2, 1, 1, 1, 1, 1, 1},
        {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1},
        {1, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 5, 5, 2, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 1},
        {1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1},
        {1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1},
        {1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1},
        {1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1},
        {1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1},
        {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1},
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};
					


void StartGame(){
	
	PacMan.x =0;
	PacMan.y=0;
	currentP.x =0;
	currentP.y =0;
	status_game=0;
	LastDrawLife.x = 30;
	LastDrawLife.y = 310;
	
	active=0; // player is not moving
	
	LCD_Initialization();
  TP_Init();
	LCD_Clear(Black);
	
	
	GUI_Text(170, 0, (uint8_t *) " SCORE ", White, Black);
	char score_str[50]; 
	sprintf(score_str, "%d", score); 
	GUI_Text(180, 20, (uint8_t *)score_str, White, Black);
	
	
	LCD_DrawBoard();
	status_game=1;
		
	return; 
}





void gameEnd(){
	GUI_Text(80, 165, (uint8_t *)"GAME OVER", White, Red);
	if(status_game==1){
		disable_timer(0);
		status_game = 3;
	}
}

void gameVictory(){
	GUI_Text(80, 165, (uint8_t *)" VICTORY ", White, Red);
	if(status_game==1){
		disable_timer(0);
		status_game = 3;
	}
}
	
void gamePause(){
	if(status_game==1){
		GUI_Text(100, 165, (uint8_t *)"PUASE", White, Red);
		disable_timer(0);
		status_game = 0;
	}
}
void gameResume(){ 
	
	if(status_game==0){
		LCD_delete_GUI(100, 165, 140 , 20); 
		status_game = 1;
		enable_timer(0);
	}
}


void setScore(){
	
	int actual_score = count_score *10 + count_score_special *50;
	
	char score_str[50];  // Creazione di una variabile stringa con spazio sufficiente
	sprintf(score_str, "%d", actual_score); 

	GUI_Text(180, 20, (uint8_t *)score_str, White, Black);
	
	if(actual_score - 1000*extra_life >= 1000){
		  LastDrawLife.x+=10;
		  extra_life++;
			DrawPacMan(LastDrawLife.x, LastDrawLife.y, 8);	
	}
}

void eatPills(int x, int y, int type_points){
				
				if(type_points == 0)count_score+=1;
				else count_score_special+=1;
	
				board[y][x] = 0;
				eaten--;
				if(eaten == 0) gameVictory();
}


int MovePacMan(int direction){
	
	if(status_game == 0 || status_game == 3) return -1;
	if (currentP.y < 0 || currentP.y >= HEIGTH || currentP.x < 0 || currentP.x >= LENGTH) {
    return -1;
	}
	
	switch(direction){
		case 1:{
			//down
			currentP.y +=1;
			if(board[currentP.y][currentP.x] == 1) {currentP.y -=1; return -1;}
			else if (board[currentP.y][currentP.x] == 2) {	
				eatPills(currentP.x,currentP.y,0);
			}
			else if (board[currentP.y][currentP.x] == 7) {	
				eatPills(currentP.x,currentP.y,1);
			}
			LCD_SetPointWithSize(PacMan.x,PacMan.y,Black,8);
			PacMan.y = currentP.y*scale+spacing_y;
			LCD_SetPointWithSize(PacMan.x,PacMan.y,Yellow,8);
			LCD_EraseCirclePortion(PacMan.x,PacMan.y, 8, 120, 220);
			break;
		}
		case 0:{
			//up
			currentP.y -=1;
			
			if(board[currentP.y][currentP.x] == 1) {currentP.y +=1; return -1;}
			else if (board[currentP.y][currentP.x] == 2) {
				eatPills(currentP.x,currentP.y,0);
			}
			else if (board[currentP.y][currentP.x] == 7) {	
				eatPills(currentP.x,currentP.y,1);
			}
			
				LCD_SetPointWithSize(PacMan.x,PacMan.y,Black,8);
			  PacMan.y = currentP.y*scale+spacing_y;
				LCD_SetPointWithSize(PacMan.x,PacMan.y,Yellow,8);
				LCD_EraseCirclePortion(PacMan.x,PacMan.y, 8, 120, 220);
			break;
		}
		case 3:{
			//right
			currentP.x +=1;
			if(board[currentP.y][currentP.x] == 1) {currentP.x -=1; return -1;}
			else if (board[currentP.y][currentP.x] == 2) {		
				eatPills(currentP.x,currentP.y,0);
			}
			else if (board[currentP.y][currentP.x] == 7) {	
				eatPills(currentP.x,currentP.y,1);
			}
			else if (board[currentP.y][currentP.x] == 6) {
				LCD_SetPointWithSize(PacMan.x,PacMan.y,Black,8);
				PacMan.x = 0*scale+spacing_x;
				currentP.x = 0;
				currentP.y = 14;
				LCD_SetPointWithSize(PacMan.x,PacMan.y,Yellow,8);
				LCD_EraseCirclePortion(PacMan.x,PacMan.y, 8, 120, 220);
				return 0;
			}
			LCD_SetPointWithSize(PacMan.x,PacMan.y,Black,8);
			PacMan.x = currentP.x*scale+spacing_x;
			LCD_SetPointWithSize(PacMan.x,PacMan.y,Yellow,8);
			LCD_EraseCirclePortion(PacMan.x,PacMan.y, 8, 120, 220);
			break;
		}
		
		case 2:{
			//left
			currentP.x -=1;
			if(board[currentP.y][currentP.x] == 1) {currentP.x +=1; return -1;}
			else if (board[currentP.y][currentP.x] == 2) {		
				
				eatPills(currentP.x,currentP.y,0);
			
			}
			else if (board[currentP.y][currentP.x] == 7) {	
				
				eatPills(currentP.x,currentP.y,1);
			
			}else if (board[currentP.y][currentP.x] == 4) {
				
				
					LCD_SetPointWithSize(PacMan.x,PacMan.y,Black,8);
					PacMan.x = 27*scale+spacing_x;
					currentP.x = 27;
					currentP.y = 14;
					LCD_SetPointWithSize(PacMan.x,PacMan.y,Yellow,8);
					LCD_EraseCirclePortion(PacMan.x,PacMan.y, 8, 120, 220);
				
				return 0;
			}
			LCD_SetPointWithSize(PacMan.x,PacMan.y,Black,8);
			PacMan.x = currentP.x*scale+spacing_x;
			LCD_SetPointWithSize(PacMan.x,PacMan.y,Yellow,8);
			LCD_EraseCirclePortion(PacMan.x,PacMan.y, 8, 120, 220);
			break;
		}
		
		default:{
		
			return 0;
		}
	}
	
	
	return 0;
}


/******************************************************************************
* Function Name  : DrawBoard
* Description    : Inizialize the board
* Input          :  
*				 
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
void LCD_DrawBoard(){ //112 120
			
			uint8_t start_GR;
			uint8_t right_GR;
			uint8_t down_GR;
			int x=0;
			int y = 0;		
			int z=0;
			srand((unsigned int)LPC_TIM0->TC);
			
			//Boundaries

			LCD_DrawLine(0+spacing_x, 0+spacing_y, 0+spacing_x, 104+spacing_y, Blue);//vertical left 1
			LCD_DrawLine(0+spacing_x, 120+spacing_y, 0+spacing_x, 240+spacing_y, Blue);//vertical left 1
			LCD_DrawLine(0+spacing_x, 0+spacing_y, 216+spacing_x, 0+spacing_y, Blue); // horizontal up
			LCD_DrawLine(216+spacing_x, 0+spacing_y, 216+spacing_x, 104+spacing_y, Blue); //vertical right_GR 1
			LCD_DrawLine(216+spacing_x, 120+spacing_y, 216+spacing_x, 240+spacing_y, Blue); //vertical right_GR 1
	    LCD_DrawLine(0+spacing_x, 240+spacing_y, 216+spacing_x, 240+spacing_y, Blue); // horizontal bottom
	
	
			
			for (y = 1; y < HEIGTH - 1; y++) {
					for (x = 1; x < LENGTH - 1; x++) {
							
					    start_GR = board[y][x] ;
						
							switch (start_GR){
								// Draw the wall 
								case 1 : {
										  right_GR = board[y][x + 1];
											down_GR = board[y + 1][x];
										
										
											//Disegna linee se le condizioni sono soddisfatte
											if (right_GR == 1) {		   
													LCD_DrawLine(x*scale+spacing_x,y*scale+spacing_y,x*scale+scale+spacing_x,y*scale+spacing_y,Blue);
											}

											if (down_GR == 1) {
													LCD_DrawLine(x*scale+spacing_x,y*scale+spacing_y,x*scale+spacing_x,y*scale+scale+spacing_y,Blue);	
													
												/*if (right_GR == 1 && board[y + 1][x+1]==1) {	
													for(z = 1; z < 8; z++){
															LCD_DrawLine(x*scale+spacing_x+z,y*scale+spacing_y,x*scale+spacing_x+z,y*scale+scale+spacing_y,Blue);	
														}
													}
												if(x==1 && ((y>=9 && y<13) || (y>=14 && y<19))){
													for(z = 1; z < 8; z++){
															LCD_DrawLine(0*scale+spacing_x+z,y*scale+spacing_y,0*scale+spacing_x+z,y*scale+scale+spacing_y,Blue);	
														}
												}*/
														
													
											}
											break; 
								}
								case 2 : {
											int random_number = rand()%30;
											if(random_number == 0 && special < 6) { 
																special++;
																board[y][x] = 7; // special point 
																LCD_SetPointWithSize(x*scale+spacing_x,y*scale+spacing_y,Red,4);	
											}
											else {LCD_SetPointWithSize(x*scale+spacing_x,y*scale+spacing_y,Magenta,2);}
											break; 
								}
								case 5 : {
										if(PacMan.y == 0){
											PacMan.y = y*scale+spacing_y;
											PacMan.x = x*scale+spacing_x+4;
											currentP.x = x;
											currentP.y = y;
											DrawPacMan(PacMan.x, PacMan.y, 8);
											}
											break; 
								}
								default : {
									break;
								}
							}
						 
					}
			}
			
			// draw lifes 
			DrawPacMan(10, 310, 8);
			DrawPacMan(20, 310, 8);
			DrawPacMan(30, 310, 8);	
	    return;
}	

void DrawPacMan(int x, int y, int size)
{
	LCD_SetPointWithSize(x,y,Yellow,size);	
	LCD_EraseCirclePortion(x, y, size, 120, 220);
}